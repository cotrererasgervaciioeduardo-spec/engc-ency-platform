/**
 * Cliente de OpenRouter — solo servidor.
 *
 * La clave OPENROUTER_API_KEY nunca debe exponerse al navegador
 * ni prefijarse con NEXT_PUBLIC_.
 */

import {
  DEFAULT_MODEL_ID,
  getModelById,
  isAllowedModelId,
  type PublicModel,
} from "@/lib/models";

export type ChatRole = "system" | "user" | "assistant";

export type ChatTurn = {
  role: ChatRole;
  content: string;
};

export type OpenRouterResult =
  | {
      connected: false;
      reason: "not_configured" | "upstream" | "timeout" | "empty";
      content: string;
      model: PublicModel;
    }
  | {
      connected: true;
      content: string;
      model: PublicModel;
    };

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const REQUEST_TIMEOUT_MS = 45_000;
const MAX_COMPLETION_TOKENS = 2048;

const SYSTEM_PROMPT =
  "Eres el asistente de ENGC ENCY, una plataforma de herramientas digitales. Responde en el idioma de la persona usuaria, con claridad y sin inventar funciones que la plataforma no tenga. No pidas ni reveles claves API. Si no sabes algo, dilo.";

export function isOpenRouterConfigured(): boolean {
  return Boolean(process.env.OPENROUTER_API_KEY?.trim());
}

export function resolveModelId(requested?: string | null): string {
  const fromEnv = process.env.OPENROUTER_MODEL?.trim();
  if (requested && isAllowedModelId(requested)) return requested;
  if (fromEnv && isAllowedModelId(fromEnv)) return fromEnv;
  return DEFAULT_MODEL_ID;
}

function extractText(content: unknown): string {
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (
          part &&
          typeof part === "object" &&
          "text" in part &&
          typeof (part as { text?: unknown }).text === "string"
        ) {
          return (part as { text: string }).text;
        }
        return "";
      })
      .join("")
      .trim();
  }
  return "";
}

export async function createChatCompletion(
  history: ChatTurn[],
  requestedModel?: string | null,
): Promise<OpenRouterResult> {
  const model = getModelById(resolveModelId(requestedModel));
  const apiKey = process.env.OPENROUTER_API_KEY?.trim();

  if (!apiKey) {
    return {
      connected: false,
      reason: "not_configured",
      model,
      content:
        "El asistente está preparado para Nex-N2.5-Pro, pero falta la clave OPENROUTER_API_KEY en el servidor. Añádela solo en el archivo .env, sin prefijo NEXT_PUBLIC_.",
    };
  }

  const payload = {
    model: model.id,
    messages: [{ role: "system", content: SYSTEM_PROMPT }, ...history],
    max_tokens: MAX_COMPLETION_TOKENS,
    temperature: 0.7,
  };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const siteUrl = process.env.SITE_URL || "http://localhost:3000";
    const response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": siteUrl,
        "X-Title": "ENGC ENCY",
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    const raw = (await response.json()) as {
      error?: { message?: string };
      choices?: Array<{ message?: { content?: unknown } }>;
      model?: string;
    };

    if (!response.ok) {
      let message = "OpenRouter no pudo completar la solicitud.";
      if (response.status === 401) {
        message = "La clave de OpenRouter no es válida. Revisa OPENROUTER_API_KEY en el servidor.";
      } else if (response.status === 402) {
        message = "La cuenta de OpenRouter no tiene crédito suficiente para Nex-N2.5-Pro.";
      } else if (response.status === 429) {
        message = "OpenRouter está limitando las solicitudes. Espera un momento e inténtalo de nuevo.";
      } else if (raw.error?.message) {
        message = "El modelo no pudo responder en este momento. Inténtalo de nuevo.";
      }
      return { connected: false, reason: "upstream", model, content: message };
    }

    const text = extractText(raw.choices?.[0]?.message?.content);
    if (!text) {
      return {
        connected: false,
        reason: "empty",
        model,
        content: "Nex-N2.5-Pro devolvió una respuesta vacía. Prueba a reformular el mensaje.",
      };
    }

    return {
      connected: true,
      content: text,
      model: raw.model && isAllowedModelId(raw.model) ? getModelById(raw.model) : model,
    };
  } catch (error) {
    const timedOut = error instanceof Error && error.name === "AbortError";
    return {
      connected: false,
      reason: timedOut ? "timeout" : "upstream",
      model,
      content: timedOut
        ? "Nex-N2.5-Pro tardó demasiado en responder. Inténtalo de nuevo."
        : "No se pudo contactar con OpenRouter. Comprueba la conexión del servidor.",
    };
  } finally {
    clearTimeout(timer);
  }
}
