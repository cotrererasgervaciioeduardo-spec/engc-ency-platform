import { catalogCategories, catalogTools } from "@/data/catalog";
import { db } from "@/db";
import { categories, tools } from "@/db/schema";

let seedPromise: Promise<void> | null = null;

async function seedCatalog() {
  for (const category of catalogCategories) {
    await db
      .insert(categories)
      .values(category)
      .onConflictDoUpdate({
        target: categories.slug,
        set: {
          name: category.name,
          description: category.description,
        },
      });
  }

  for (const tool of catalogTools) {
    await db
      .insert(tools)
      .values(tool)
      .onConflictDoUpdate({
        target: tools.slug,
        set: {
          name: tool.name,
          shortDescription: tool.shortDescription,
          longDescription: tool.longDescription,
          categorySlug: tool.categorySlug,
          status: tool.status,
          icon: tool.icon,
          featured: tool.featured,
          sortOrder: tool.sortOrder,
        },
      });
  }
}

export async function ensureCatalogSeeded() {
  if (!seedPromise) {
    seedPromise = seedCatalog().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  await seedPromise;
}
