export type ToolStatus = "preview" | "coming_soon";

export type CatalogCategory = {
  slug: string;
  name: string;
  description: string;
};

export type CatalogTool = {
  slug: string;
  name: string;
  shortDescription: string;
  longDescription: string;
  categorySlug: string;
  status: ToolStatus;
  icon: string;
  featured: boolean;
  sortOrder: number;
};

export const catalogCategories: CatalogCategory[] = [
  {
    slug: "inteligencia-artificial",
    name: "Inteligencia artificial",
    description: "Espacios preparados para asistentes y flujos de trabajo con IA.",
  },
  {
    slug: "escritura",
    name: "Escritura",
    description: "Ayudas para redactar, resumir y traducir con más claridad.",
  },
  {
    slug: "estudio",
    name: "Estudio",
    description: "Recursos para aprender, organizar apuntes y practicar.",
  },
  {
    slug: "programacion",
    name: "Programación",
    description: "Apoyo para leer código, documentar y desbloquear problemas.",
  },
  {
    slug: "creatividad",
    name: "Creatividad",
    description: "Generadores de ideas y estímulos para proyectos nuevos.",
  },
  {
    slug: "productividad",
    name: "Productividad",
    description: "Utilidades para planificar, priorizar y mantener el foco.",
  },
];

export const catalogTools: CatalogTool[] = [
  {
    slug: "asistente-ia",
    name: "Asistente de inteligencia artificial",
    shortDescription:
      "Una interfaz conversacional para consultar, redactar y explorar ideas.",
    longDescription:
      "El asistente de ENGC ENCY usa Nex-N2.5-Pro (Nex-AGI) a través de OpenRouter, siempre desde el servidor. El identificador del modelo es nex-agi/nex-n2.5-pro. Para activarlo hay que definir OPENROUTER_API_KEY solo en el entorno del servidor, nunca en el navegador.",
    categorySlug: "inteligencia-artificial",
    status: "preview",
    icon: "spark",
    featured: true,
    sortOrder: 1,
  },
  {
    slug: "generador-textos",
    name: "Generador de textos",
    shortDescription:
      "Borradores, esquemas y variaciones para escribir con más agilidad.",
    longDescription:
      "Esta herramienta ayudará a empezar un texto, proponer estructuras y explorar tonos distintos. Todavía no genera contenido: el catálogo y la ficha ya están listos para cuando se conecte el backend de IA.",
    categorySlug: "escritura",
    status: "coming_soon",
    icon: "pen",
    featured: true,
    sortOrder: 2,
  },
  {
    slug: "resumidor",
    name: "Resumidor de documentos",
    shortDescription:
      "Síntesis claras de textos largos para localizar lo esencial.",
    longDescription:
      "El resumidor se diseñará para condensar documentos extensos en ideas clave, sin inventar datos. En esta versión la ficha es informativa y puedes apuntarte para recibir aviso cuando esté disponible.",
    categorySlug: "escritura",
    status: "coming_soon",
    icon: "layers",
    featured: true,
    sortOrder: 3,
  },
  {
    slug: "ayudante-programacion",
    name: "Ayudante de programación",
    shortDescription:
      "Explicaciones, revisión de lógica y apoyo al aprendizaje de código.",
    longDescription:
      "Pensado para acompañar el estudio y la práctica de programación: leer un fragmento, explicar un error o proponer un plan de trabajo. No ejecuta código remoto ni ofrece exploits; su propósito es educativo y de productividad.",
    categorySlug: "programacion",
    status: "coming_soon",
    icon: "code",
    featured: true,
    sortOrder: 4,
  },
  {
    slug: "generador-ideas",
    name: "Generador de ideas",
    shortDescription:
      "Estímulos creativos para proyectos, nombres, enfoques y variaciones.",
    longDescription:
      "Un espacio para desbloquear el inicio de un proyecto: preguntas, ángulos y combinaciones. La generación automática se incorporará cuando el asistente esté conectado.",
    categorySlug: "creatividad",
    status: "coming_soon",
    icon: "bulb",
    featured: true,
    sortOrder: 5,
  },
  {
    slug: "estudio",
    name: "Herramientas para estudiar",
    shortDescription:
      "Guías, fichas y planes de repaso para aprender con más método.",
    longDescription:
      "Agrupará utilidades de estudio como esquemas, preguntas de autoevaluación y planificación de repaso. Por ahora puedes explorar la categoría y dejar tu interés.",
    categorySlug: "estudio",
    status: "coming_soon",
    icon: "book",
    featured: true,
    sortOrder: 6,
  },
  {
    slug: "traductor",
    name: "Traductor de textos",
    shortDescription:
      "Traducción cuidada entre idiomas, con contexto y tono conservados.",
    longDescription:
      "El traductor se integrará como utilidad de escritura. Esta ficha describe el propósito; todavía no procesa textos ni llama a servicios externos.",
    categorySlug: "escritura",
    status: "coming_soon",
    icon: "globe",
    featured: true,
    sortOrder: 7,
  },
  {
    slug: "productividad",
    name: "Herramientas de productividad",
    shortDescription:
      "Listas, prioridades y recordatorios para organizar el trabajo diario.",
    longDescription:
      "Un conjunto de utilidades para ordenar tareas y mantener el foco. En esta etapa la categoría está publicada para exploración; las funciones interactivas llegarán más adelante.",
    categorySlug: "productividad",
    status: "coming_soon",
    icon: "check",
    featured: true,
    sortOrder: 8,
  },
  {
    slug: "guia-prompts",
    name: "Guía de prompts",
    shortDescription:
      "Modelos de pregunta para obtener respuestas más precisas.",
    longDescription:
      "Una biblioteca de plantillas para formular mejor una petición a un asistente. El contenido interactivo se publicará junto a la conexión del chatbot.",
    categorySlug: "inteligencia-artificial",
    status: "coming_soon",
    icon: "compass",
    featured: false,
    sortOrder: 9,
  },
  {
    slug: "organizador-notas",
    name: "Organizador de notas",
    shortDescription:
      "Captura rápida de ideas y agrupación por temas o proyectos.",
    longDescription:
      "Pensado para guardar notas breves y clasificarlas. Todavía no almacena contenido de usuario más allá del interés por la herramienta.",
    categorySlug: "productividad",
    status: "coming_soon",
    icon: "note",
    featured: false,
    sortOrder: 10,
  },
  {
    slug: "tarjetas-estudio",
    name: "Tarjetas de estudio",
    shortDescription:
      "Fichas de pregunta y respuesta para memorizar con repaso espaciado.",
    longDescription:
      "Una utilidad de estudio basada en tarjetas. La creación automática a partir de apuntes se activará cuando exista conexión con el backend de IA.",
    categorySlug: "estudio",
    status: "coming_soon",
    icon: "cards",
    featured: false,
    sortOrder: 11,
  },
  {
    slug: "planificador",
    name: "Planificador de enfoque",
    shortDescription:
      "Bloques de tiempo y prioridades para jornadas de trabajo más claras.",
    longDescription:
      "Ayudará a partir un día o una semana en bloques realistas. En esta versión la ficha es un avance del producto, sin calendario conectado.",
    categorySlug: "productividad",
    status: "coming_soon",
    icon: "calendar",
    featured: false,
    sortOrder: 12,
  },
];

export const projectUpdates = [
  {
    id: "base-visual",
    title: "Identidad y base visual",
    dateLabel: "Etapa 1",
    body: "Se publica la identidad ENGC ENCY, el catálogo de herramientas y la navegación principal. Datos de demostración del propio proyecto.",
  },
  {
    id: "catalogo",
    title: "Catálogo explorables",
    dateLabel: "Etapa 1",
    body: "Buscador, filtros por categoría y fichas con estado honesto de disponibilidad. Ninguna herramienta afirma usar IA real todavía.",
  },
  {
    id: "chat-demo",
    title: "Interfaz del asistente",
    dateLabel: "Etapa 1",
    body: "La ventana de conversación está lista como demostración. No hay conexión con modelos externos ni claves en el navegador.",
  },
  {
    id: "openrouter",
    title: "Modelo Nex-N2.5-Pro",
    dateLabel: "Etapa 2",
    body: "El asistente queda configurado con nex-agi/nex-n2.5-pro. Las respuestas reales requieren OPENROUTER_API_KEY en el servidor.",
  },
] as const;
