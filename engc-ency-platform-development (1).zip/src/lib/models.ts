export type PublicModel = {
  id: string;
  name: string;
  label: string;
};

export const ALLOWED_MODELS: readonly PublicModel[] = [
  {
    id: "nex-agi/nex-n2.5-pro",
    name: "Nex-N2.5-Pro",
    label: "Nex-N2.5-Pro · Nex-AGI",
  },
];

export const DEFAULT_MODEL_ID = "nex-agi/nex-n2.5-pro";

export function getModelById(id: string | undefined | null): PublicModel {
  const match = ALLOWED_MODELS.find((model) => model.id === id);
  return match ?? ALLOWED_MODELS[0];
}

export function isAllowedModelId(id: string): boolean {
  return ALLOWED_MODELS.some((model) => model.id === id);
}
