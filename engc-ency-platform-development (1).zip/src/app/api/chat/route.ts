import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { DEFAULT_MODEL_ID, getModelById } from "@/lib/models";
import { checkRateLimit, getClientKey } from "@/lib/rate-limit";
import { normalizeConversationId, normalizeMessage } from "@/lib/validation";
import {
  createChatCompletion,
  isOpenRouterConfigured,
  resolveModelId,
  type ChatTurn,
} from "@/services/openrouter";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HISTORY_LIMIT = 16;

export async function GET() {
  const model = getModelById(resolveModelId());
  return Response.json({
    configured: isOpenRouterConfigured(),
    model,
    defaultModelId: DEFAULT_MODEL_ID,
  });
}

export async function POST(request: Request) {
  const limited = checkRateLimit(`chat:${getClientKey(request)}`, 12, 60_000);
  if (!limited.ok) {
    return Response.json(
      { error: "Has enviado demasiados mensajes seguidos. Espera un momento." },
      { status: 429 },
    );
  }

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return Response.json({ error: "La solicitud no es válida." }, { status: 400 });
  }

  if (!payload || typeof payload !== "object") {
    return Response.json({ error: "La solicitud no es válida." }, { status: 400 });
  }

  const body = payload as {
    message?: unknown;
    conversationId?: unknown;
    model?: unknown;
  };
  const content = normalizeMessage(body.message);
  const conversationId = normalizeConversationId(body.conversationId);
  const requestedModel = typeof body.model === "string" ? body.model : null;

  if (!content) {
    return Response.json(
      { error: "Escribe un mensaje de hasta 4000 caracteres." },
      { status: 400 },
    );
  }

  try {
    let activeId = conversationId;

    if (activeId) {
      const found = await db
        .select({ id: conversations.id })
        .from(conversations)
        .where(eq(conversations.id, activeId))
        .limit(1);
      if (found.length === 0) {
        activeId = null;
      }
    }

    if (!activeId) {
      const created = await db
        .insert(conversations)
        .values({})
        .returning({ id: conversations.id });
      activeId = created[0]?.id ?? null;
    }

    if (!activeId) {
      return Response.json(
        { error: "No se pudo iniciar la conversación." },
        { status: 500 },
      );
    }

    await db.insert(messages).values({
      conversationId: activeId,
      role: "user",
      content,
      source: "user",
    });

    const historyRows = await db
      .select({
        role: messages.role,
        content: messages.content,
      })
      .from(messages)
      .where(eq(messages.conversationId, activeId))
      .orderBy(asc(messages.createdAt));

    const history: ChatTurn[] = historyRows
      .filter((row) => row.role === "user" || row.role === "assistant")
      .slice(-HISTORY_LIMIT)
      .map((row) => ({
        role: row.role as "user" | "assistant",
        content: row.content,
      }));

    const completion = await createChatCompletion(history, requestedModel);

    if (!completion.connected) {
      const status = completion.reason === "not_configured" ? 503 : 502;
      return Response.json(
        {
          error: completion.content,
          connected: false,
          conversationId: activeId,
          model: completion.model,
        },
        { status },
      );
    }

    await db.insert(messages).values({
      conversationId: activeId,
      role: "assistant",
      content: completion.content,
      source: "openrouter",
    });

    await db
      .update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, activeId));

    return Response.json({
      connected: true,
      conversationId: activeId,
      model: completion.model,
      message: {
        role: "assistant",
        content: completion.content,
      },
    });
  } catch {
    return Response.json(
      { error: "No se pudo completar el mensaje. Inténtalo de nuevo." },
      { status: 500 },
    );
  }
}
