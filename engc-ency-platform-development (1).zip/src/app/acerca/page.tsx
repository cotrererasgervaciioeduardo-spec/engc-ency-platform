import Image from "next/image";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Acerca de",
  description:
    "ENGC ENCY es un proyecto tecnológico que reúne herramientas digitales e inteligencia artificial en un mismo espacio.",
};

export default function AboutPage() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <p className="text-xs uppercase tracking-[0.24em] text-cyan">El proyecto</p>
      <h1 className="font-display mt-3 max-w-3xl text-4xl text-mist sm:text-5xl">
        Un espacio común para herramientas digitales e inteligencia artificial.
      </h1>
      <p className="mt-5 max-w-2xl text-lg leading-8 text-fog">
        ENGC ENCY nace para reunir utilidades de escritura, estudio, programación
        y productividad sin pretender ser un producto terminado antes de tiempo.
      </p>

      <div className="mt-10 overflow-hidden rounded-[2rem]">
        <Image
          src="/images/about.jpg"
          alt="Mesa de trabajo nocturna con una geometría holográfica suave, sin personas."
          width={1600}
          height={900}
          className="h-72 w-full object-cover sm:h-96"
        />
      </div>

      <section className="mt-12 grid gap-6 md:grid-cols-2">
        <article className="card-surface rounded-3xl p-6">
          <h2 className="font-display text-2xl text-mist">Propósito</h2>
          <p className="mt-3 text-sm leading-7 text-fog">
            Ofrecer un punto de partida claro para explorar herramientas
            digitales y, más adelante, un asistente conectado de forma segura
            desde el servidor.
          </p>
        </article>
        <article className="card-surface rounded-3xl p-6">
          <h2 className="font-display text-2xl text-mist">Objetivos</h2>
          <p className="mt-3 text-sm leading-7 text-fog">
            Publicar un catálogo honesto, una identidad visual propia y una
            arquitectura que permita crecer sin improvisar claves, modelos ni
            promesas.
          </p>
        </article>
        <article className="card-surface rounded-3xl p-6">
          <h2 className="font-display text-2xl text-mist">Productividad y aprendizaje</h2>
          <p className="mt-3 text-sm leading-7 text-fog">
            Las categorías se eligieron para acompañar el trabajo diario y el
            estudio: redactar, resumir, practicar código, organizar ideas y
            planificar.
          </p>
        </article>
        <article className="card-surface rounded-3xl p-6">
          <h2 className="font-display text-2xl text-mist">Privacidad</h2>
          <p className="mt-3 text-sm leading-7 text-fog">
            No pedimos cuentas para navegar. El único dato opcional es un correo
            para avisar de una herramienta. Las claves de servicios externos, si
            se añaden, vivirán solo en el servidor.
          </p>
        </article>
      </section>

      <section className="card-surface mt-8 rounded-[2rem] p-6 sm:p-8">
        <h2 className="font-display text-2xl text-mist">Modelo del asistente</h2>
        <p className="mt-3 max-w-3xl text-sm leading-7 text-fog">
          El chat usa Nex-N2.5-Pro (`nex-agi/nex-n2.5-pro`) mediante OpenRouter.
          La clave vive solo en el servidor. Si no está configurada, el asistente
          lo indica con claridad y no inventa respuestas. Esta página no
          representa una empresa, un equipo comercial ni alianzas.
        </p>
      </section>
    </main>
  );
}
