"use client";

import { useEffect, useId, useRef, useState } from "react";
import { DEFAULT_MODEL_ID, type PublicModel } from "@/lib/models";

type ChatItem = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

const FALLBACK_MODEL: PublicModel = {
  id: DEFAULT_MODEL_ID,
  name: "Nex-N2.5-Pro",
  label: "Nex-N2.5-Pro · Nex-AGI",
};

function welcomeMessage(isConfigured: boolean, current: PublicModel) {
  return isConfigured
    ? `Hola. Estoy conectado a ${current.name} a través del servidor de ENGC ENCY. Pregunta lo que necesites.`
    : `El modelo elegido es ${current.name}. Todavía falta OPENROUTER_API_KEY en el servidor, así que no puedo generar respuestas reales. Cuando la clave esté en el .env del servidor, este mismo chat la usará.`;
}

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<ChatItem[]>([
    {
      id: "welcome",
      role: "assistant",
      content: welcomeMessage(false, FALLBACK_MODEL),
    },
  ]);
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [configured, setConfigured] = useState(false);
  const [model, setModel] = useState<PublicModel>(FALLBACK_MODEL);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const titleId = useId();

  useEffect(() => {
    let cancelled = false;
    async function loadStatus() {
      try {
        const response = await fetch("/api/chat");
        const data = (await response.json()) as {
          configured?: boolean;
          model?: PublicModel;
        };
        if (cancelled) return;
        const nextModel = data.model?.name ? data.model : FALLBACK_MODEL;
        const nextConfigured = Boolean(data.configured);
        setConfigured(nextConfigured);
        setModel(nextModel);
        setItems((current) => {
          if (current.length > 1) return current;
          return [
            {
              id: "welcome",
              role: "assistant",
              content: welcomeMessage(nextConfigured, nextModel),
            },
          ];
        });
      } catch {
        if (!cancelled) setConfigured(false);
      }
    }
    void loadStatus();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (open) {
      inputRef.current?.focus();
    }
  }, [open]);

  useEffect(() => {
    const node = listRef.current;
    if (node) {
      node.scrollTop = node.scrollHeight;
    }
  }, [items, pending, open]);

  function resetConversation() {
    setItems([
      {
        id: "welcome",
        role: "assistant",
        content: welcomeMessage(configured, model),
      },
    ]);
    setConversationId(null);
    setError("");
    setInput("");
  }

  async function sendMessage(event?: React.FormEvent) {
    event?.preventDefault();
    const text = input.trim();
    if (!text || pending) return;

    const userItem: ChatItem = {
      id: crypto.randomUUID(),
      role: "user",
      content: text,
    };
    setItems((current) => [...current, userItem]);
    setInput("");
    setPending(true);
    setError("");

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          conversationId,
          model: model.id,
        }),
      });
      const data = (await response.json()) as {
        error?: string;
        conversationId?: string;
        connected?: boolean;
        model?: PublicModel;
        message?: { content?: string };
      };

      if (data.model?.name) setModel(data.model);
      if (data.conversationId) setConversationId(data.conversationId);

      if (!response.ok) {
        setError(data.error ?? "No se pudo enviar el mensaje.");
        return;
      }

      setItems((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: data.message?.content ?? "No llegó contenido del modelo.",
        },
      ]);
    } catch {
      setError("No se pudo contactar con el servidor. Inténtalo de nuevo.");
    } finally {
      setPending(false);
    }
  }

  function onKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void sendMessage();
    }
  }

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-50 flex justify-end p-4 sm:p-6">
      <div className="pointer-events-auto flex flex-col items-end gap-3">
        {open ? (
          <section
            className="flex h-[min(34rem,78vh)] w-[min(100vw-2rem,24rem)] flex-col overflow-hidden rounded-3xl border border-white/10 bg-[#0b1220]/95 shadow-[0_24px_80px_rgba(0,0,0,0.45)] backdrop-blur-xl"
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
          >
            <header className="flex items-start justify-between gap-3 border-b border-white/8 bg-[url('/images/chat-backdrop.jpg')] bg-cover bg-center px-4 py-3">
              <div className="rounded-2xl bg-[#070b14]/80 p-3">
                <p className="text-[0.65rem] uppercase tracking-[0.2em] text-cyan">
                  {configured ? "Conectado" : "Pendiente de clave"}
                </p>
                <h2 id={titleId} className="font-display text-lg text-mist">
                  Asistente ENGC ENCY
                </h2>
                <p className="text-xs text-fog">{model.label}</p>
              </div>
              <div className="flex gap-1">
                <button
                  type="button"
                  className="rounded-full border border-white/10 bg-black/30 px-3 py-1 text-xs text-mist"
                  onClick={resetConversation}
                >
                  Nueva
                </button>
                <button
                  type="button"
                  className="rounded-full border border-white/10 bg-black/30 px-3 py-1 text-xs text-mist"
                  onClick={() => setOpen(false)}
                >
                  Cerrar
                </button>
              </div>
            </header>
            <div
              ref={listRef}
              className="chat-scroll flex-1 space-y-3 overflow-y-auto px-4 py-4"
            >
              {items.map((item) => (
                <div
                  key={item.id}
                  className={`max-w-[90%] rounded-2xl px-3 py-2 text-sm leading-6 ${
                    item.role === "user"
                      ? "ml-auto bg-cyan/15 text-mist"
                      : "bg-white/5 text-fog"
                  }`}
                >
                  <p className="mb-1 text-[0.65rem] uppercase tracking-[0.16em] text-cyan/80">
                    {item.role === "user" ? "Tú" : model.name}
                  </p>
                  <p className="whitespace-pre-wrap">{item.content}</p>
                </div>
              ))}
              {pending ? (
                <p className="text-xs text-cyan" role="status">
                  {configured ? `${model.name} está escribiendo…` : "Comprobando conexión…"}
                </p>
              ) : null}
              {error ? (
                <p className="rounded-2xl border border-amber-200/20 bg-amber-200/8 px-3 py-2 text-sm text-amber-100" role="alert">
                  {error}
                </p>
              ) : null}
            </div>
            <form onSubmit={sendMessage} className="border-t border-white/8 p-3">
              <label className="sr-only" htmlFor="chat-input">
                Escribe un mensaje
              </label>
              <div className="flex items-end gap-2">
                <textarea
                  id="chat-input"
                  ref={inputRef}
                  rows={2}
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={onKeyDown}
                  maxLength={4000}
                  placeholder={
                    configured
                      ? `Mensaje para ${model.name}`
                      : "Escribe para probar. Falta la clave de OpenRouter."
                  }
                  className="min-h-[3rem] flex-1 resize-none rounded-2xl border border-white/10 bg-black/25 px-3 py-2 text-sm text-mist placeholder:text-fog/70"
                />
                <button
                  type="submit"
                  className="btn-primary rounded-2xl px-4 py-3 text-sm disabled:opacity-50"
                  disabled={pending || input.trim().length === 0}
                >
                  Enviar
                </button>
              </div>
            </form>
          </section>
        ) : null}
        <button
          type="button"
          className="glow-ring grid h-14 w-14 place-items-center rounded-full bg-[#0d1a24] text-cyan"
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <span className="sr-only">
            {open ? "Cerrar asistente" : "Abrir asistente Nex-N2.5-Pro"}
          </span>
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
            {open ? (
              <path d="M6 6l12 12M18 6 6 18" />
            ) : (
              <>
                <path d="M5 12c0-4 3.2-7 7-7s7 3 7 7-3.2 7-7 7H8l-3 2v-4.2C5.3 15.4 5 13.8 5 12Z" />
                <path d="M9 12h.01M12 12h.01M15 12h.01" />
              </>
            )}
          </svg>
        </button>
      </div>
    </div>
  );
}
