# ENGC ENCY

Plataforma web de herramientas digitales e inteligencia artificial.

El asistente usa **Nex-N2.5-Pro** (`nex-agi/nex-n2.5-pro`) a través de OpenRouter. La clave vive solo en el servidor.

## Qué está listo

- Página de inicio, catálogo, explorar y acerca de.
- Buscador, filtros y ordenación del catálogo (datos reales en PostgreSQL).
- Fichas de herramientas con estado honesto (`Vista previa` o `Próximamente`).
- Formulario de aviso de disponibilidad (correo + herramienta, validado en servidor).
- Chat flotante configurado con Nex-N2.5-Pro.
- Ruta `/api/chat` que llama a OpenRouter cuando existe `OPENROUTER_API_KEY`.

## Qué sigue siendo demostración

- Si no hay `OPENROUTER_API_KEY`, el chat **no** inventa respuestas de un modelo.
- El resto de herramientas del catálogo no ejecutan IA todavía.
- Las novedades de Explorar son hitos internos del proyecto.

## Requisitos

- Node.js 20 o superior
- PostgreSQL
- Una clave de OpenRouter para activar Nex-N2.5-Pro

El frontend es Next.js (App Router). Las rutas `/api/*` necesitan un runtime Node.js.

## Instalación y arranque

```bash
npm install
cp .env.example .env
npx drizzle-kit push
npm run dev
```

En `.env` del servidor:

```bash
OPENROUTER_API_KEY=tu_clave
OPENROUTER_MODEL=nex-agi/nex-n2.5-pro
```

No uses el prefijo `NEXT_PUBLIC_` y no pongas la clave en componentes cliente.

Compilación de producción:

```bash
npm run build
npm run start
```

## Variables de entorno

| Variable | Ámbito | Uso |
| --- | --- | --- |
| `DATABASE_URL` | Servidor | Conexión PostgreSQL |
| `OPENROUTER_API_KEY` | Servidor | Clave de OpenRouter |
| `OPENROUTER_MODEL` | Servidor | Por defecto `nex-agi/nex-n2.5-pro` |
| `SITE_URL` | Servidor | Metadatos y cabecera HTTP-Referer |

## Dónde está el modelo

1. `src/lib/models.ts` — lista permitida; el predeterminado es Nex-N2.5-Pro.
2. `src/services/openrouter.ts` — llamada a `https://openrouter.ai/api/v1/chat/completions`.
3. `src/app/api/chat/route.ts` — validación, historial, límites y errores.

Para cambiar de modelo más adelante, añade el id a `ALLOWED_MODELS` y, si quieres, `OPENROUTER_MODEL`. El cliente no puede pedir un modelo fuera de esa lista.
