import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { InterestForm } from "@/components/interest-form";
import { StatusBadge } from "@/components/status-badge";
import { ToolCard } from "@/components/tool-card";
import { ToolIcon } from "@/components/icons";
import { getRelatedTools, getToolBySlug } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type PageProps = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const tool = await getToolBySlug(slug);
  if (!tool) {
    return { title: "Herramienta no encontrada" };
  }
  return {
    title: tool.name,
    description: tool.shortDescription,
  };
}

export default async function ToolDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const tool = await getToolBySlug(slug);
  if (!tool) notFound();

  const related = await getRelatedTools(tool.slug, tool.categorySlug);

  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <Link href="/herramientas" className="text-sm text-cyan hover:underline">
        ← Volver al catálogo
      </Link>
      <div className="mt-8 grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <article className="card-surface rounded-[2rem] p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-4">
            <span className="grid h-14 w-14 place-items-center rounded-2xl border border-cyan/20 bg-cyan/8 text-cyan">
              <ToolIcon name={tool.icon} className="h-7 w-7" />
            </span>
            <StatusBadge status={tool.status} />
          </div>
          <h1 className="font-display mt-6 text-4xl text-mist">{tool.name}</h1>
          <p className="mt-2 text-xs uppercase tracking-[0.2em] text-fog">{tool.categoryName}</p>
          <p className="mt-6 text-lg leading-8 text-fog">{tool.longDescription}</p>
          <div className="mt-8 rounded-2xl border border-white/8 bg-black/20 p-5 text-sm leading-6 text-fog">
            {tool.status === "preview" ? (
              <p>
                Vista previa: puedes abrir el botón flotante del asistente para
                probar la interfaz. Las respuestas no provienen de un modelo de
                inteligencia artificial.
              </p>
            ) : (
              <p>
                Esta herramienta todavía no está operativa. No genera textos, no
                procesa documentos y no llama a servicios externos.
              </p>
            )}
          </div>
        </article>
        <InterestForm slug={tool.slug} name={tool.name} />
      </div>
      {related.length > 0 ? (
        <section className="mt-14">
          <h2 className="font-display text-2xl text-mist">En la misma categoría</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-3">
            {related.map((item) => (
              <ToolCard key={item.slug} tool={item} />
            ))}
          </div>
        </section>
      ) : null}
    </main>
  );
}


