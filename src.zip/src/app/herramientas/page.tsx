import { ToolsCatalog } from "@/components/tools-catalog";
import { getCategories, getTools } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Herramientas",
  description:
    "Catálogo de herramientas digitales de ENGC ENCY, con buscador, filtros y estados de disponibilidad.",
};

type PageProps = {
  searchParams: Promise<{ categoria?: string; q?: string }>;
};

export default async function ToolsPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const [tools, categories] = await Promise.all([getTools(), getCategories()]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <p className="text-xs uppercase tracking-[0.24em] text-cyan">Catálogo</p>
      <h1 className="font-display mt-3 text-4xl text-mist sm:text-5xl">Herramientas</h1>
      <p className="mt-4 max-w-2xl text-base leading-7 text-fog">
        Explora las categorías iniciales de ENGC ENCY. El buscador y los filtros
        funcionan con el catálogo del proyecto. Las funciones de inteligencia
        artificial se marcarán como conectadas solo cuando lo estén.
      </p>
      <div className="mt-10">
        <ToolsCatalog
          tools={tools}
          categories={categories}
          initialQuery={params.q ?? ""}
          initialCategory={params.categoria ?? "todas"}
        />
      </div>
    </main>
  );
}
