export default function ToolsLoading() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <div className="h-4 w-24 rounded-full bg-white/8" />
      <div className="mt-4 h-12 w-64 rounded-2xl bg-white/8" />
      <div className="mt-10 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="h-56 rounded-3xl bg-white/5" />
        ))}
      </div>
      <p className="sr-only">Cargando catálogo de herramientas</p>
    </main>
  );
}
