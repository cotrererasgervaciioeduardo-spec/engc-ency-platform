import Image from "next/image";
import Link from "next/link";
import { projectUpdates } from "@/data/catalog";
import { ToolCard } from "@/components/tool-card";
import { getCategories, getFeaturedTools } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Explorar",
  description:
    "Descubre categorías, novedades del proyecto y accesos rápidos de ENGC ENCY.",
};

export default async function ExplorePage() {
  const [featured, categories] = await Promise.all([getFeaturedTools(), getCategories()]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <div className="relative overflow-hidden rounded-[2rem]">
        <Image
          src="/images/explore-panel.jpg"
          alt="Horizonte geométrico abstracto en azul marino con luz cian suave."
          width={1600}
          height={700}
          className="h-64 w-full object-cover opacity-70 sm:h-80"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#05070d] via-[#05070d]/70 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-end p-6 sm:p-10">
          <p className="text-xs uppercase tracking-[0.24em] text-cyan">Descubrir</p>
          <h1 className="font-display mt-2 text-4xl text-mist sm:text-5xl">Explorar ENGC ENCY</h1>
        </div>
      </div>

      <section className="mt-12">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-display text-3xl text-mist">Herramientas destacadas</h2>
          <Link href="/herramientas" className="text-sm text-cyan hover:underline">
            Catálogo
          </Link>
        </div>
        <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {featured.slice(0, 4).map((tool) => (
            <ToolCard key={tool.slug} tool={tool} />
          ))}
        </div>
      </section>

      <section className="mt-14">
        <h2 className="font-display text-3xl text-mist">Categorías populares</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((category) => (
            <Link
              key={category.slug}
              href={`/herramientas?categoria=${category.slug}`}
              className="card-surface rounded-3xl p-5 transition"
            >
              <h3 className="font-display text-xl text-mist">{category.name}</h3>
              <p className="mt-2 text-sm leading-6 text-fog">{category.description}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-14 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div>
          <h2 className="font-display text-3xl text-mist">Novedades del proyecto</h2>
          <p className="mt-2 text-sm text-fog">
            Actualizaciones internas de ENGC ENCY. No son estadísticas de uso ni
            testimonios de terceros.
          </p>
          <ol className="mt-6 space-y-4">
            {projectUpdates.map((update) => (
              <li key={update.id} className="card-surface rounded-3xl p-5">
                <p className="text-[0.7rem] uppercase tracking-[0.18em] text-cyan">{update.dateLabel}</p>
                <h3 className="font-display mt-2 text-xl text-mist">{update.title}</h3>
                <p className="mt-2 text-sm leading-6 text-fog">{update.body}</p>
              </li>
            ))}
          </ol>
        </div>
        <aside className="card-surface rounded-[2rem] p-6">
          <h2 className="font-display text-2xl text-mist">Accesos rápidos</h2>
          <ul className="mt-5 space-y-3 text-sm">
            <li>
              <Link className="text-cyan hover:underline" href="/herramientas">
                Buscar en el catálogo
              </Link>
            </li>
            <li>
              <Link className="text-cyan hover:underline" href="/herramientas/asistente-ia">
                Ver ficha del asistente
              </Link>
            </li>
            <li>
              <Link className="text-cyan hover:underline" href="/acerca">
                Propósito y privacidad
              </Link>
            </li>
          </ul>
          <div className="mt-8 rounded-2xl border border-white/8 bg-black/20 p-4 text-sm leading-6 text-fog">
            Disponibilidad actual: catálogo operativo, avisos de interés
            guardados en base de datos, chatbot en modo demostración.
          </div>
        </aside>
      </section>
    </main>
  );
}
