import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { toolInterest, tools } from "@/db/schema";
import { ensureCatalogSeeded } from "@/db/seed";
import { checkRateLimit, getClientKey } from "@/lib/rate-limit";
import { normalizeEmail, normalizeSlug } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const limited = checkRateLimit(`interest:${getClientKey(request)}`, 8, 60_000);
  if (!limited.ok) {
    return Response.json(
      { error: "Has enviado demasiadas solicitudes. Espera un momento e inténtalo de nuevo." },
      { status: 429 },
    );
  }

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return Response.json({ error: "La solicitud no es válida." }, { status: 400 });
  }

  if (!payload || typeof payload !== "object") {
    return Response.json({ error: "La solicitud no es válida." }, { status: 400 });
  }

  const body = payload as { email?: unknown; slug?: unknown };
  const email = normalizeEmail(body.email);
  const slug = normalizeSlug(body.slug);

  if (!email) {
    return Response.json(
      { error: "Introduce un correo electrónico válido." },
      { status: 400 },
    );
  }

  if (!slug) {
    return Response.json({ error: "La herramienta no es válida." }, { status: 400 });
  }

  try {
    await ensureCatalogSeeded();
    const tool = await db.select({ slug: tools.slug }).from(tools).where(eq(tools.slug, slug)).limit(1);
    if (tool.length === 0) {
      return Response.json({ error: "No encontramos esa herramienta." }, { status: 404 });
    }

    const already = await db
      .select({ id: toolInterest.id })
      .from(toolInterest)
      .where(and(eq(toolInterest.email, email), eq(toolInterest.toolSlug, slug)))
      .limit(1);

    if (already.length === 0) {
      await db.insert(toolInterest).values({ email, toolSlug: slug });
    }

    return Response.json({
      ok: true,
      message: "Hemos guardado tu interés. Te avisaremos cuando esta herramienta esté disponible.",
    });
  } catch {
    return Response.json(
      { error: "No se pudo guardar el interés. Inténtalo más tarde." },
      { status: 500 },
    );
  }
}
