import { getCategories, getTools } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [items, categories] = await Promise.all([getTools(), getCategories()]);
    return Response.json({ tools: items, categories });
  } catch {
    return Response.json(
      { error: "No se pudo cargar el catálogo de herramientas." },
      { status: 500 },
    );
  }
}
