import { checkRateLimit, getClientKey } from "@/lib/rate-limit";
import { normalizeMessage } from "@/lib/validation";
import {
  createChatCompletion,
  isOpenRouterConfigured,
  type ChatTurn,
} from "@/services/openrouter";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const DEMO_MESSAGE =
  "La conexión con modelos de inteligencia artificial todavía no está habilitada. " +
  "Configura OPENROUTER_API_KEY en el servidor para activar el asistente.";

export async function GET() {
  return Response.json(
    { configured: isOpenRouterConfigured(), demo: !isOpenRouterConfigured() },
    { headers: { "Cache-Control": "no-store" } },
  );
}

export async function POST(request: Request) {
  const limited = checkRateLimit(`chat:${getClientKey(request)}`, 10, 60_000);
  if (!limited.ok) {
    return Response.json(
      { error: "Has enviado demasiados mensajes seguidos. Espera un momento." },
      { status: 429, headers: { "Cache-Control": "no-store" } },
    );
  }

  let payload: unknown;
  try {
    const raw = await request.text();
    if (raw.length > 32_000) {
      return Response.json({ error: "La solicitud es demasiado grande." }, { status: 413 });
    }
    payload = JSON.parse(raw);
  } catch {
    return Response.json({ error: "La solicitud no es válida." }, { status: 400 });
  }

  if (!payload || typeof payload !== "object") {
    return Response.json({ error: "La solicitud no es válida." }, { status: 400 });
  }

  const body = payload as { message?: unknown; messages?: unknown };
  const content = normalizeMessage(body.message, 4000);
  if (!content) {
    return Response.json(
      { error: "Escribe un mensaje de hasta 4000 caracteres." },
      { status: 400 },
    );
  }

  if (!isOpenRouterConfigured()) {
    return Response.json({
      demo: true,
      connected: false,
      message: { role: "assistant", content: DEMO_MESSAGE },
    }, { headers: { "Cache-Control": "no-store" } });
  }

  const rawMessages = Array.isArray(body.messages) ? body.messages : [];
  if (rawMessages.length > 12) {
    return Response.json(
      { error: "La conversación es demasiado larga. Inicia una conversación nueva." },
      { status: 400 },
    );
  }

  const history: ChatTurn[] = [];
  for (const item of rawMessages) {
    if (!item || typeof item !== "object") {
      return Response.json({ error: "El historial no es válido." }, { status: 400 });
    }
    const turn = item as { role?: unknown; content?: unknown };
    if (turn.role !== "user" && turn.role !== "assistant") {
      return Response.json({ error: "El historial contiene un rol no permitido." }, { status: 400 });
    }
    const normalized = normalizeMessage(turn.content, 4000);
    if (!normalized) {
      return Response.json({ error: "Un mensaje del historial no es válido." }, { status: 400 });
    }
    history.push({ role: turn.role, content: normalized });
  }

  // The server trusts only user/assistant turns, never a client-supplied system prompt.
  // Ensure the latest user message is the validated message from this request.
  const messages = history.slice(-11);
  if (
    messages.length === 0 ||
    messages[messages.length - 1]?.role !== "user" ||
    messages[messages.length - 1]?.content !== content
  ) {
    messages.push({ role: "user", content });
  }

  try {
    const completion = await createChatCompletion(messages);
    return Response.json({
      demo: false,
      connected: true,
      model: completion.model,
      message: { role: "assistant", content: completion.content },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    // Log only a safe error category, never the request content or API key.
    const category = error instanceof Error ? error.message : "UNKNOWN";
    console.error("ENGC ENCY chat request failed:", category);
    if (category === "OPENROUTER_NOT_CONFIGURED") {
      return Response.json({ error: "El asistente todavía no está configurado." }, { status: 503 });
    }
    if (category.startsWith("OPENROUTER_HTTP_")) {
      return Response.json(
        { error: "El proveedor de IA no pudo completar la solicitud. Revisa el modelo y los límites de tu cuenta." },
        { status: 502, headers: { "Cache-Control": "no-store" } },
      );
    }
    if (category === "TimeoutError" || category === "AbortError") {
      return Response.json(
        { error: "La respuesta tardó demasiado. Inténtalo de nuevo." },
        { status: 504, headers: { "Cache-Control": "no-store" } },
      );
    }
    return Response.json(
      { error: "No se pudo obtener una respuesta. Inténtalo de nuevo." },
      { status: 502, headers: { "Cache-Control": "no-store" } },
    );
  }
}
